package AVLTree;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.swing.JFrame;
import javax.swing.JTree;

public class test {

	public static void main(String[] args) throws IOException {
		AVLTree avltree = new AVLTree();
		FileInputStream tree = new FileInputStream("src/AVLTree/tree_data.dat");
		InputStreamReader isr = new InputStreamReader(tree);
		BufferedReader br = new BufferedReader(isr);
		int Size = 0;
		for(int i = 0;i > 0;i++)
		{	
			String a = br.readLine();
			Size++;
			if(a == null)
			{
				Size--;
				break;
			}
		}
		Node[] nodeList = new Node[Size];
		for(int i = 0;i<Size;i++)
			nodeList[i].setData(br.readLine());
        
        JTree a = avltree.printTree(nodeList);  
        br.close();
        
        
        JFrame frame = new JFrame("AVLTree");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(a);
        frame.pack();
        frame.setVisible(true);
	}

}
