package AVLTree;
import javax.swing.JTree;
import javax.swing.JButton;


public class AVLTree implements IAVLTree{

	int Size;
	Node[] AVLTree = new Node[Size]; 
	Node root = new Node();
	
	
	public Node get(int id)
	{
		Node a = new Node();
		for(int i = 0;i < Size; i++){
			if(i == id) 
				a = AVLTree[i];
				return a;
		}
		return null;
	}
	
	public void rotateLeft(Node a)
	{
		if(a != null)
		{
			Node b = new Node();
			b = a.right;
			a.right = b.left;
			if(b.left != null)
				b.left.setParent(a);
			b.setParent(a.getParent());
			if(a.getParent() == null)
				root = b;
			else if(a.getParent().left == a)
				a.getParent().left = b;
			else
				a.getParent().right = b;
			b.left = a;
			a.setParent(b);
		}
	}
	
	public void rotateRight(Node a)
	{
		if(a != null)
		{
			Node b = new Node();
			b = a.left;
			a.left = b.right;
			if(b.right != null)
				b.right.setParent(a);
			b.setParent(a.getParent());
			if(a.getParent() == null)
				root = b;
			else if(a.getParent().right == a)
				a.getParent().right = b;
			else 
				a.getParent().left = b;
			b.right = a;
			a.setParent(b);
		}
	}
	
	public void insert(int id, Node newNode)
	{
		for(int i = Size; i >= id; i--)
		{
			AVLTree[i+1] = AVLTree[i];	
		}
		AVLTree[id] = newNode;
		Size ++;
		
		//�ж�ƽ���������ɲ���������Ƿ�ƽ��
		for(int i = 0; i < Size;i++)
		{
			if(AVLTree[i].getBalanceFactor()>=2)
			{
				rotateRight(AVLTree[i]);
			}
		    if(AVLTree[i].getBalanceFactor()<=-2)
		    {
                rotateLeft(AVLTree[i]);			
		    }
		}
	}
	
	public void delete(int id)
	{
		for(int i = id;i < Size; i++)
			AVLTree[i] = AVLTree[i+1];
		Size --;
		if(AVLTree[id].left != null || AVLTree[id].right != null)
		{
			if(AVLTree[id].left != null)
				AVLTree[id] = AVLTree[id].left;
			else if(AVLTree[id].right != null)
				AVLTree[id] = AVLTree[id].right;
			else 
				AVLTree[id].left = AVLTree[id].right = AVLTree[id] = null;
		}
		else if(AVLTree[id].getParent() == null)
			root = null;
		else 
		{
			if(AVLTree[id].getParent() != null)
			{
				if(AVLTree[id] == AVLTree[id].getParent().left)
					AVLTree[id].getParent().left = null;
				else if(AVLTree[id] == AVLTree[id].getParent().right)
					AVLTree[id].getParent().right = null;
			    AVLTree[id].setParent(null);
			}
		}					
	}
	
	public JTree printTree()
	{
		return printTree(AVLTree);	
	}
	
	public JTree printTree(Node[] AVLTree)
	{
		JTree tree = new JTree();
		for(int i = 0;i < Size;i++)
		{
			JButton TreeNode = new JButton();
			TreeNode.setText(AVLTree[i].toString());
		    tree.add(TreeNode);
		}
		return tree;
	}
	
	
	
	
	
}
